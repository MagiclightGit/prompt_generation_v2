# magic_prompt_generation

## Setup submodule

Setup submodule for the first time:

```sh
$ git submodule update --init
```

Every time submodule update:

```sh
$ git submodule update --recursive --remote
```

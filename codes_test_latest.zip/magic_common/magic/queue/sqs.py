import logging

import boto3

from magic.utils.json import safe_load_json


logger = logging.getLogger()


class SQSClient(object):

    def __init__(self, region, queue_url):
        self.client = boto3.client("sqs", region_name=region)
        self.queue_url = queue_url

    def fetch_messages(self, max_message_num=1, queue_url=None, delete_on_fetch=False, timeout=10):
        queue_url = queue_url or self.queue_url

        resp = self.client.receive_message(
            QueueUrl=queue_url,
            MaxNumberOfMessages=max_message_num,
            WaitTimeSeconds=timeout,
            AttributeNames=["All"],
        )
        messages = resp.get('Messages', [])
        if delete_on_fetch:
            for msg in messages:
                self.delete_message(msg, queue_url)
        return messages

    def put_message(self, queue_url, body):
        resp = self.client.send_message(
            QueueUrl=queue_url,
            MessageBody=body,
        )
        return resp

    def delete_message(self, sqs_message, queue_url=None):
        return self.client.delete_message(
            QueueUrl=queue_url,
            ReceiptHandle=sqs_message.get('ReceiptHandle'),
        )

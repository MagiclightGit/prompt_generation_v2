import os


def get_root_path():
    return os.path.dirname(os.path.realpath(__name__))

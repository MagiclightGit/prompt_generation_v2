class TaskError(Exception):
    pass


class RetryableTaskError(Exception):
    pass

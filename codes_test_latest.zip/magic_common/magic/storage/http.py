import os

import requests


def http_download_to_file(url, local_filepath):
    # TODO: wrap with retry
    resp = requests.get(url)
    if resp.status_code == 200:
        with open(local_filepath, 'wb') as out:
            out.write(resp.content)
        return local_filepath
